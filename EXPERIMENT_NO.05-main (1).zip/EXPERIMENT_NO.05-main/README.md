Experiment 5: Frontend with React and TypeScript ⚛️
Location: Exp5/src/App.tsx, Exp5/package.json

Technologies: React, TypeScript, Vite

Description: A modern, single-page registration form built with React and TypeScript. Implements state management using React hooks (useState) for handling form inputs and validation logic. The project uses Vite for fast development and building.

How to Run:
# Navigate to the experiment directory
cd Exp5

# Install dependencies
npm install

# Start the development server
npm run dev

# The application will be available at http://localhost:5173
